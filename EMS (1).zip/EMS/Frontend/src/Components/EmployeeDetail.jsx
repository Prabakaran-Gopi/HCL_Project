import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

// Import the CSS file
import './EmployeeDetails.css';

const EmployeeDetail = () => {
    const [employee, setEmployee] = useState([]);
    const { id } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        axios.get(`http://localhost:3000/employee/detail/${id}`)
            .then(result => {
                setEmployee(result.data[0]);
            })
            .catch(err => console.log(err));
    }, [id]);

    const handleLogout = () => {
        axios.get('http://localhost:3000/employee/logout')
            .then(result => {
                if (result.data.Status) {
                    localStorage.removeItem("valid");
                    navigate('/');
                }
            }).catch(err => console.log(err));
    };

    return (
        <div className="employee-detail-container">
            <div className="header">
                <h4>Employee Management System</h4>
                {/* Logout button at the top right corner */}
                <button className="logout-button" onClick={handleLogout}>Logout</button>
            </div>
            <div className="main-content">
                {/* Image on the left side */}
                <div className="image-section">
                    <img src={`http://localhost:3000/Images/${employee.image}`} className="employee-image" alt="Employee" />
                </div>
                
                {/* Employee details on the right side */}
                <div className="details-section">
                    <p>Personal Details</p>
                    <h3>Name: {employee.name}</h3>
                    <h3>Email: {employee.email}</h3>
                    <h3>Salary: ${employee.salary}</h3>
                    <h3>Address: {employee.address}</h3>
                </div>
            </div>
        </div>
    );
};

export default EmployeeDetail;
