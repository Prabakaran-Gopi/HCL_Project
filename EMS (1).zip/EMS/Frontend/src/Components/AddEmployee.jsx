import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddEmployee = () => {
    // Define state for employee data
    const [employee, setEmployee] = useState({
        name: "",
        email: "",
        password: "",
        salary: "",
        address: "",
        image: null,
        category_id: "",
    });

    // State for category data
    const [categories, setCategories] = useState([]);

    // Initialize navigation function
    const navigate = useNavigate();

    // Fetch categories from server on component mount
    useEffect(() => {
        // Define the API endpoint for fetching categories
        const fetchCategories = async () => {
            try {
                const response = await axios.get("http://localhost:3000/auth/category");
                // Set the categories in state
                setCategories(response.data.Result);
            } catch (error) {
                console.error("Error fetching categories:", error);
            }
        };

        // Call the function to fetch categories
        fetchCategories();
    }, []);

    // Handle form submission
    const handleSubmit = (e) => {
        e.preventDefault();

        // Create a new FormData object to hold the form data
        const formData = new FormData();
        formData.append("name", employee.name);
        formData.append("email", employee.email);
        formData.append("password", employee.password);
        formData.append("address", employee.address);
        formData.append("salary", employee.salary);
        formData.append("image", employee.image);
        formData.append("category_id", employee.category_id);

        // Send a POST request to the server to add the employee
        axios.post("http://localhost:3000/auth/add_employee", formData)
            .then((result) => {
                if (result.data.Status) {
                    // Successfully added employee
                    navigate("/dashboard/employee");
                } else {
                    // Handle error
                    alert(result.data.Error);
                }
            })
            .catch((err) => console.log(err));
    };

    // Render the form
    return (
        <div className="d-flex justify-content-center align-items-center mt-3">
            <div className="p-3 rounded w-50 border">
                <h3 className="text-center">Add Employee</h3>
                <form className="row g-1" onSubmit={handleSubmit}>
                    <div className="col-12">
                        <label htmlFor="inputName" className="form-label">
                            Name
                        </label>
                        <input
                            type="text"
                            className="form-control rounded-0"
                            id="inputName"
                            placeholder="Enter Name"
                            onChange={(e) =>
                                setEmployee({ ...employee, name: e.target.value })
                            }
                        />
                    </div>
                    <div className="col-12">
                        <label htmlFor="inputEmail4" className="form-label">
                            Email
                        </label>
                        <input
                            type="email"
                            className="form-control rounded-0"
                            id="inputEmail4"
                            placeholder="Enter Email"
                            autoComplete="off"
                            onChange={(e) =>
                                setEmployee({ ...employee, email: e.target.value })
                            }
                        />
                    </div>
                    <div className="col-12">
                        <label htmlFor="inputPassword4" className="form-label">
                            Password
                        </label>
                        <input
                            type="password"
                            className="form-control rounded-0"
                            id="inputPassword4"
                            placeholder="Enter Password"
                            onChange={(e) =>
                                setEmployee({ ...employee, password: e.target.value })
                            }
                        />
                    </div>
                    <div className="col-12">
                        <label htmlFor="inputSalary" className="form-label">
                            Salary
                        </label>
                        <input
                            type="number"
                            className="form-control rounded-0"
                            id="inputSalary"
                            placeholder="Enter Salary"
                            autoComplete="off"
                            onChange={(e) =>
                                setEmployee({ ...employee, salary: e.target.value })
                            }
                        />
                    </div>
                    <div class="col-12">
                        <label htmlFor="inputAddress" className="form-label">
                            Address
                        </label>
                        <input
                            type="text"
                            className="form-control rounded-0"
                            id="inputAddress"
                            placeholder="Enter Address"
                            autoComplete="off"
                            onChange={(e) =>
                                setEmployee({ ...employee, address: e.target.value })
                            }
                        />
                    </div>
                    <div className="col-12">
                        <label htmlFor="inputCategory" className="form-label">
                            Category
                        </label>
                        <select
                            className="form-select rounded-0"
                            id="inputCategory"
                            value={employee.category_id}
                            onChange={(e) =>
                                setEmployee({ ...employee, category_id: e.target.value })
                            }
                        >
                            {/* Populate category options from the fetched data */}
                            <option value="">Select Category</option>
                            {categories.map((category) => (
                                <option key={category.id} value={category.id}>
                                    {category.name}
                                </option>
                            ))}
                        </select>
                    </div>
                    <div className="col-12">
                        <label htmlFor="inputImage" className="form-label">
                            Image
                        </label>
                        <input
                            type="file"
                            className="form-control rounded-0"
                            id="inputImage"
                            onChange={(e) =>
                                setEmployee({ ...employee, image: e.target.files[0] })
                            }
                        />
                    </div>
                    <div className="col-12">
                        <button
                            type="submit"
                            className="btn btn-primary w-100 rounded-0"
                        >
                            Add Employee
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default AddEmployee;
